

const {BrowserWindow} = require('electron')
let win = new BrowserWindow({transparent: true, frame: false})
win.show()

//window.styleMask.insert(NSFullSizeContentViewWindowMask)

//const {BrowserWindow} = require('electron')
//let win = new BrowserWindow({titleBarStyle: 'hidden'})
//win.show()

//window.titlebarAppearsTransparent = true
//window.titleVisibility = .Hidden
//window.styleMask |= NSFullSizeContentViewWindowMask 

